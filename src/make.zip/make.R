# makefile 

source("src/get_data.R")
# source("src/clean_data.R")
# take this second piece out to speed up iteration and not tax website